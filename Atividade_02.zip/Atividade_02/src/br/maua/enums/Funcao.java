package br.maua.enums;

public enum Funcao {
    MOBILE_MEMBER, HEAVY_LIFTER, SCRIPT_GUY, BIG_BROTHER
}
