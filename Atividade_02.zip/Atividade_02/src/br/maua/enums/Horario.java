package br.maua.enums;

public enum Horario {
    REGULAR, EXTRA
}
