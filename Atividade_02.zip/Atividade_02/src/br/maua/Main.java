// Nome: Matheus Takahashi Nakai
//   Ra: 19.01355-8

package br.maua;

import br.maua.controlador.Sistema;

import java.util.Calendar;

public class Main {

    public static void main(String[] args) {

        Sistema sistema = new Sistema();
        sistema.executar();


    }
}
