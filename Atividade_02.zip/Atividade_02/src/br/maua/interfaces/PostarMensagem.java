package br.maua.interfaces;

import br.maua.enums.Horario;

public interface PostarMensagem {
    String postarMensagem(Horario horario);
}
