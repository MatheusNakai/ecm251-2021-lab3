package br.maua.interfaces;

public interface Apresentacao {
    String apresentar();
}
